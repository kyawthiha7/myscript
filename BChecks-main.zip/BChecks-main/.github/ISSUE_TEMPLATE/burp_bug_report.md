---
name: Bug report
about: Create a bug report to help us improve BChecks within Burp Suite
title: "[BUG]"
labels: bug
assignees: ''

---

### Current behavior



### Expected behavior



### Environment details

  - Burp version:
  - BCheck language version:
  - Operating system:


### Additional details
