---
name: Feature request
about: Suggest an enhancement for BChecks
title: "[FEATURE]"
labels: enhancement
assignees: ''

---

### What is the problem you are trying to solve?



### How are you currently being hindered by this problem? 



### How would you like this problem to be solved? 



### Any additional details?
