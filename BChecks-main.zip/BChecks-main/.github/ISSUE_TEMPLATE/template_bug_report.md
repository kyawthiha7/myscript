---
name: BCheck template bug
about: Create a bug report to report an issue with a specific BCheck
title: "[BUG]"
labels: bug, template
assignees: ''

---

### Path of script within repository



### Current behavior



### Expected behavior



### Environment details

  - Burp version:
  - BCheck language version:
  - Operating system:


### Additional details
