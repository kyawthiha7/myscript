### BCheck Contributions

* [ ] BCheck compiles and executes as expected
* [ ] BCheck contains appropriate metadata (name, version, author, description and appropriate tags)
* [ ] Only .bcheck files have been added or modified
* [ ] BCheck is in the appropriate folder
* [ ] PR contains single or limited number of BChecks (Multiple PRs are preferred)
* [ ] BCheck attempts to minimize false positives
